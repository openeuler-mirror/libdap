#ifndef E_test_config_h
#define E_test_config_h

#define TEST_SRC_DIR "/Users/jimg/src/opendap/hyrax_git/libdap4/unit-tests"

#endif

