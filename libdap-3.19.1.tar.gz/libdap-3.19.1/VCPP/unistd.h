/* Dummy patch header to get win32 flex/bison generated */ 
/* source code to compile under win32. If you see this */ 
/* temp file, feel free to scratch it. */ 
#include "io.h" 
